# book_dialogs.py
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QLineEdit, QTextEdit, QDialogButtonBox, QCheckBox
)


class AddEntryDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("添加新世界书条目")
        self.setMinimumWidth(500)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(10)

        self.keys_edit = QLineEdit()
        self.keys_edit.setPlaceholderText("关键词1, 关键词2...")
        layout.addWidget(QLabel("关键词（逗号分隔）:"))
        layout.addWidget(self.keys_edit)

        self.content_edit = QTextEdit()
        self.content_edit.setPlaceholderText("世界书内容...")
        self.content_edit.setMinimumHeight(140)
        layout.addWidget(QLabel("内容:"))
        layout.addWidget(self.content_edit)

        self.enabled_check = QCheckBox("启用此条目")
        self.enabled_check.setChecked(True)
        layout.addWidget(self.enabled_check)

        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def get_data(self):
        keys = [k.strip() for k in self.keys_edit.text().split(',') if k.strip()]
        return {
            "keys": keys,
            "content": self.content_edit.toPlainText().strip(),
            "enabled": self.enabled_check.isChecked()
        }


class EditBookEntryDialog(QDialog):
    def __init__(self, entry_data, parent=None):
        super().__init__(parent)
        self.setWindowTitle("编辑世界书条目")
        self.setMinimumWidth(520)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(10)

        self.keys_edit = QLineEdit()
        self.keys_edit.setText(", ".join(entry_data.get("keys", [])))
        layout.addWidget(QLabel("关键词（逗号分隔）:"))
        layout.addWidget(self.keys_edit)

        self.content_edit = QTextEdit()
        self.content_edit.setPlainText(entry_data.get("content", ""))
        self.content_edit.setMinimumHeight(160)
        layout.addWidget(QLabel("内容:"))
        layout.addWidget(self.content_edit)

        self.enabled_check = QCheckBox("启用此条目")
        self.enabled_check.setChecked(entry_data.get("enabled", True))
        layout.addWidget(self.enabled_check)

        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def get_data(self):
        keys = [k.strip() for k in self.keys_edit.text().split(',') if k.strip()]
        return {
            "keys": keys,
            "content": self.content_edit.toPlainText().strip(),
            "enabled": self.enabled_check.isChecked()
        }