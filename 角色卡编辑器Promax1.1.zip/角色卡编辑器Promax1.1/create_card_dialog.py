# create_card_dialog_v2.py
# 新建角色卡对话框 - 简洁浅色现代风格

import os
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QLineEdit,
    QTextEdit, QScrollArea, QFileDialog, QMessageBox, QDialogButtonBox,
    QFrame, QWidget
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont


class CreateCharacterDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("新建角色卡")
        self.setMinimumSize(820, 720)
        self.setStyleSheet("""
            QDialog {
                background-color: #F8FAFC;
            }
            QLineEdit, QTextEdit {
                background-color: #FFFFFF;
                border: 1px solid #E2E8F0;
                border-radius: 8px;
                padding: 8px 12px;
                font-size: 13px;
            }
            QLineEdit:focus, QTextEdit:focus {
                border: 1px solid #3B82F6;
            }
            QLabel {
                color: #334155;
                font-size: 13px;
            }
        """)

        self.widgets = {}
        self.image_path = None

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(20, 16, 20, 16)
        main_layout.setSpacing(12)

        # 标题
        title_label = QLabel("创建新角色卡")
        title_label.setStyleSheet("font-size: 18px; font-weight: 700; color: #0F172A; margin-bottom: 8px;")
        main_layout.addWidget(title_label)

        # 滚动区域
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(QFrame.NoFrame)

        content_widget = QWidget()
        form_layout = QVBoxLayout(content_widget)
        form_layout.setSpacing(14)
        form_layout.setContentsMargins(4, 4, 4, 4)

        # === 基础信息 ===
        form_layout.addWidget(self._create_section_label("基础信息"))
        form_layout.addLayout(self.create_labeled_input("名称（必填）:", "name", ""))
        form_layout.addLayout(self.create_labeled_input("创建者:", "creator", ""))
        form_layout.addLayout(self.create_labeled_input("角色版本:", "character_version", ""))
        form_layout.addLayout(self.create_labeled_input("标签（逗号分隔）:", "tags", ""))

        # === 核心设定 ===
        form_layout.addWidget(self._create_section_label("核心设定"))
        form_layout.addLayout(self.create_labeled_input("描述与设定:", "description", "", multiline=True))
        form_layout.addLayout(self.create_labeled_input("性格:", "personality", "", multiline=True))
        form_layout.addLayout(self.create_labeled_input("场景:", "scenario", "", multiline=True))

        # === 对话内容 ===
        form_layout.addWidget(self._create_section_label("对话内容"))
        form_layout.addLayout(self.create_labeled_input("开场白:", "first_mes", "", multiline=True))
        form_layout.addLayout(self.create_labeled_input("备用问候语（每行一个）:", "alternate_greetings", "", multiline=True))
        form_layout.addLayout(self.create_labeled_input("对话示例:", "mes_example", "", multiline=True))

        # === 高级设置 ===
        form_layout.addWidget(self._create_section_label("高级设置"))
        form_layout.addLayout(self.create_labeled_input("系统提示（System Prompt）:", "system_prompt", "", multiline=True))
        form_layout.addLayout(self.create_labeled_input("后历史指令:", "post_history_instructions", "", multiline=True))
        form_layout.addLayout(self.create_labeled_input("创建者笔记:", "creator_notes", "", multiline=True))

        form_layout.addStretch()
        scroll_area.setWidget(content_widget)
        main_layout.addWidget(scroll_area)

        # 图片选择区域
        image_frame = QFrame()
        image_frame.setStyleSheet("""
            QFrame {
                background-color: #FFFFFF;
                border: 1px solid #E2E8F0;
                border-radius: 10px;
            }
        """)
        image_layout = QHBoxLayout(image_frame)
        image_layout.setContentsMargins(16, 12, 16, 12)
        image_layout.setSpacing(12)

        self.select_image_btn = QPushButton("选择 PNG 图片作为载体（必选）")
        self.select_image_btn.setFixedHeight(36)
        self.select_image_btn.clicked.connect(self.select_image)

        self.image_path_label = QLabel("尚未选择图片...")
        self.image_path_label.setStyleSheet("color: #64748B; font-size: 12px;")
        self.image_path_label.setWordWrap(True)

        image_layout.addWidget(self.select_image_btn)
        image_layout.addWidget(self.image_path_label, 1)

        main_layout.addWidget(image_frame)

        # 底部按钮
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.button(QDialogButtonBox.Ok).setText("创建角色卡")
        button_box.button(QDialogButtonBox.Cancel).setText("取消")
        button_box.accepted.connect(self.validate_and_accept)
        button_box.rejected.connect(self.reject)

        # 美化确定按钮
        ok_btn = button_box.button(QDialogButtonBox.Ok)
        ok_btn.setObjectName("primaryButton")
        ok_btn.setFixedHeight(38)

        main_layout.addWidget(button_box)

    def _create_section_label(self, text):
        label = QLabel(text)
        label.setStyleSheet("""
            font-size: 14px; 
            font-weight: 600; 
            color: #0F172A; 
            margin-top: 8px;
            margin-bottom: 4px;
        """)
        return label

    def create_labeled_input(self, label_text, key, data_value, multiline=False):
        h_layout = QHBoxLayout()
        h_layout.setSpacing(10)

        label = QLabel(label_text)
        label.setFixedWidth(160)
        label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        h_layout.addWidget(label)

        if multiline:
            widget = QTextEdit()
            widget.setPlainText(data_value or "")
            widget.setMinimumHeight(70)
            widget.setStyleSheet("QTextEdit { padding: 6px; }")
        else:
            widget = QLineEdit()
            widget.setText(data_value or "")

        self.widgets[key] = widget
        h_layout.addWidget(widget, 1)
        return h_layout

    def select_image(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "选择图片作为角色卡载体（支持 JPG/PNG）",
            "",
            "图片文件 (*.png *.jpg *.jpeg *.webp)"
        )
        if file_path:
            self.image_path = file_path
            self.image_path_label.setText(file_path)
            self.image_path_label.setStyleSheet("color: #166534; font-size: 12px;")

    def validate_and_accept(self):
        if not self.widgets['name'].text().strip():
            QMessageBox.warning(self, "输入缺失", "角色“名称”是必填项。")
            return
        if not self.image_path:
            QMessageBox.warning(self, "选择缺失", "请选择一个PNG图片作为角色卡的载体。")
            return
        self.accept()

    def get_data(self):
        data = {}
        for key, widget in self.widgets.items():
            if isinstance(widget, QTextEdit):
                data[key] = widget.toPlainText().strip()
            else:
                data[key] = widget.text().strip()
        return data, self.image_path
