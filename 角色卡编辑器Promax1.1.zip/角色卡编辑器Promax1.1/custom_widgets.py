# custom_widgets.py
from PySide6.QtWidgets import QLabel, QTextEdit, QFrame, QToolButton, QWidget, QVBoxLayout, QSizePolicy
from PySide6.QtGui import QPixmap, QPainter, QPainterPath
from PySide6.QtCore import Qt, QSize, QRectF, QTimer


class RoundedAvatarLabel(QLabel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(88, 88)
        self.setScaledContents(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet("border: 2px solid #E2E8F0; border-radius: 44px; background-color: #F8FAFC;")

    def setPixmap(self, pixmap):
        if pixmap.isNull():
            super().setPixmap(pixmap)
            return
        rounded = QPixmap(self.size())
        rounded.fill(Qt.transparent)
        painter = QPainter(rounded)
        painter.setRenderHint(QPainter.Antialiasing)
        path = QPainterPath()
        path.addEllipse(QRectF(0, 0, self.width(), self.height()))
        painter.setClipPath(path)
        painter.drawPixmap(0, 0, pixmap.scaled(self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation))
        painter.end()
        super().setPixmap(rounded)


class AutoResizingTextEdit(QTextEdit):
    def __init__(self, parent=None, max_height=320):
        super().__init__(parent)
        self.max_height = max_height
        self.setLineWrapMode(QTextEdit.WidgetWidth)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.document().contentsChanged.connect(self._adjust_height)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)

    def _adjust_height(self):
        doc = self.document()
        doc.adjustSize()
        doc_height = doc.size().height() + 12
        new_height = min(max(int(doc_height), 90), self.max_height)
        self.setMinimumHeight(new_height)
        self.updateGeometry()

    def adjust_height_to_content(self):
        QTimer.singleShot(0, self._adjust_height)


class CollapsibleBox(QFrame):
    def __init__(self, title="", parent=None):
        super().__init__(parent)
        self.setObjectName("collapsibleBox")
        self.setStyleSheet("""
            QFrame#collapsibleBox {
                background-color: #FFFFFF;
                border: 1px solid #E2E8F0;
                border-radius: 8px;
            }
        """)

        self.toggle_button = QToolButton()
        self.toggle_button.setText(title)
        self.toggle_button.setCheckable(True)
        self.toggle_button.setChecked(True)
        self.toggle_button.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.toggle_button.setArrowType(Qt.DownArrow)
        self.toggle_button.setStyleSheet("""
            QToolButton {
                border: none;
                background: transparent;
                padding: 8px 12px;
                font-weight: 600;
                font-size: 12.5px;
                color: #0F172A;
            }
            QToolButton:hover { background-color: #F1F5F9; }
        """)

        self.content_area = QWidget()
        self.content_layout = QVBoxLayout(self.content_area)
        self.content_layout.setContentsMargins(12, 4, 12, 10)
        self.content_layout.setSpacing(6)

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        main_layout.addWidget(self.toggle_button)
        main_layout.addWidget(self.content_area)

        self.toggle_button.toggled.connect(self.toggle)

    def toggle(self, checked):
        self.toggle_button.setArrowType(Qt.DownArrow if checked else Qt.RightArrow)
        self.content_area.setVisible(checked)

    def setContentLayout(self, layout):
        while self.content_layout.count():
            item = self.content_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.content_layout.addLayout(layout)