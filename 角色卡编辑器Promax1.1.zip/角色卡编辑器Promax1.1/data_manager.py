# data_manager.py
import os
import json

from core_utils import (
    extract_character_data_from_png,
    CARD_WORKSPACE,
    BOOK_WORKSPACE,
    CONFIG_FILE
)


class DataManager:
    def __init__(self):
        self.characters = {}
        self.setup_workspace()
        self.load_config()
        # 让 self.groups 直接指向 config 里的 groups，保持同步
        self.groups = self.config.setdefault("groups", {"未分组": []})

    def setup_workspace(self):
        os.makedirs(CARD_WORKSPACE, exist_ok=True)
        os.makedirs(BOOK_WORKSPACE, exist_ok=True)

    def load_config(self):
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
        else:
            self.config = {"groups": {"未分组": []}}

        # 自动初始化 token_settings
        if "token_settings" not in self.config:
            self.config["token_settings"] = {
                "use_custom_formula": False,
                "english_char_coef": 0.3,
                "chinese_char_coef": 0.6
            }

        # 弱化清理：只保留仍然存在的文件路径
        all_card_paths = set(self.get_workspace_cards())
        groups = self.config.setdefault("groups", {"未分组": []})

        for group_name in list(groups.keys()):
            groups[group_name] = [p for p in groups[group_name] if p in all_card_paths]

        self.config["groups"] = groups

    def save_config(self):
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, indent=4, ensure_ascii=False)

    def get_workspace_cards(self):
        return [os.path.join(CARD_WORKSPACE, f) for f in os.listdir(CARD_WORKSPACE) if f.lower().endswith('.png')]

    def load_character_data(self, path):
        if path not in self.characters:
            data, format_str = extract_character_data_from_png(path)
            if data:
                self.characters[path] = {'data': data, 'format': format_str}
            elif format_str == "Invalid Image":
                self.characters[path] = {'data': {'name': '[图片损坏或无法读取]'}, 'format': 'Invalid'}
            else:
                self.characters[path] = {'data': {'name': f'[无角色数据] {os.path.basename(path)}'},
                                         'format': 'No Data'}
        return self.characters.get(path)