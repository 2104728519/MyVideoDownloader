# detail_view_v4.py
# 角色编辑界面 V4 - 强化自动高度 + 更紧凑优化版

import os
import json
import shutil
import tiktoken
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QLineEdit,
    QTextEdit, QTabWidget, QScrollArea, QFrame, QCheckBox, QFileDialog, QMessageBox,
    QSpinBox, QToolButton, QSizePolicy, QDialog, QDialogButtonBox, QMenu,
    QListWidget, QListWidgetItem
)
from custom_widgets import RoundedAvatarLabel, AutoResizingTextEdit, CollapsibleBox
from book_dialogs import AddEntryDialog, EditBookEntryDialog
from PySide6.QtGui import QPixmap, QFont, QPainter, QPainterPath, QAction
from PySide6.QtCore import Qt, QSize, Slot, QRectF
from core_utils import write_character_data_to_png, BOOK_WORKSPACE


class DetailWidget(QWidget):
    def update_token_count(self):
        """更新 Token 显示（安全版）"""
        if not hasattr(self, 'token_label'):
            return

        # 防止在界面还没创建完成时就调用
        if not hasattr(self, 'name_edit'):
            return

        try:
            total = 0

            # 基础信息
            if hasattr(self, 'name_edit'):
                total += self.count_tokens(self.name_edit.text())
            if hasattr(self, 'creator_edit'):
                total += self.count_tokens(self.creator_edit.text())
            if hasattr(self, 'version_edit'):
                total += self.count_tokens(self.version_edit.text())

            # 其他字段
            for key, widget in self.widgets.items():
                if isinstance(widget, QTextEdit):
                    total += self.count_tokens(widget.toPlainText())
                elif isinstance(widget, QLineEdit):
                    total += self.count_tokens(widget.text())

            # 世界书（简单统计）
            if hasattr(self, 'book_entries_data'):
                for entry in self.book_entries_data:
                    if entry.get("enabled", True):
                        total += self.count_tokens("".join(entry.get("keys", [])))
                        total += self.count_tokens(entry.get("content", ""))

            self.token_label.setText(f"Token: {total}")

            # 根据数值改变颜色
            if total < 1200:
                color_style = "color: #166534; background-color: #DCFCE7; border: 1px solid #86EFAC;"
            elif total < 2000:
                color_style = "color: #854D0E; background-color: #FEF3C7; border: 1px solid #FCD34D;"
            else:
                color_style = "color: #991B1B; background-color: #FEE2E2; border: 1px solid #FCA5A5;"

            self.token_label.setStyleSheet(f"""
                QLabel {{
                    font-size: 13px;
                    {color_style}
                    border-radius: 6px;
                    padding: 4px 10px;
                    font-weight: 600;
                }}
            """)

        except Exception as e:
            print(f"Token 更新出错: {e}")
    def show_token_detail(self, event):
        """点击 Token 标签时显示详细分布"""
        if not hasattr(self, 'name_edit'):
            return

        detail_text = "Token 分布（粗略估算）:\n\n"
        detail_text += f"名称: {self.count_tokens(self.name_edit.text())}\n"

        if hasattr(self, 'creator_edit'):
            detail_text += f"创建者: {self.count_tokens(self.creator_edit.text())}\n"
        if hasattr(self, 'version_edit'):
            detail_text += f"版本: {self.count_tokens(self.version_edit.text())}\n\n"

        for key, widget in self.widgets.items():
            if isinstance(widget, QTextEdit):
                text = widget.toPlainText()
            elif isinstance(widget, QLineEdit):
                text = widget.text()
            else:
                continue

            if text.strip():
                detail_text += f"{key}: {self.count_tokens(text)}\n"

        # 世界书
        if hasattr(self, 'book_entries_data'):
            wb_total = 0
            for entry in self.book_entries_data:
                if entry.get("enabled", True):
                    wb_total += self.count_tokens("".join(entry.get("keys", [])))
                    wb_total += self.count_tokens(entry.get("content", ""))
            if wb_total > 0:
                detail_text += f"\n世界书（启用条目）: {wb_total}\n"

        QMessageBox.information(self, "Token 详细分布", detail_text)

    def change_avatar(self, event):
        """点击头像更换图片并保留角色数据"""
        new_image_path, _ = QFileDialog.getOpenFileName(
            self, "选择新的角色卡图片", "", "PNG Files (*.png)"
        )
        if not new_image_path:
            return

        try:
            # 备份当前角色数据
            current_data = self.char_data.copy()

            # 用新图片覆盖当前角色卡文件
            shutil.copy2(new_image_path, self.char_path)

            # 把角色数据重新写入新图片
            success, msg = write_character_data_to_png(self.char_path, current_data)
            if not success:
                QMessageBox.critical(self, "更换失败", f"无法将数据写入新图片：\n{msg}")
                return

            # 更新内存数据
            self.char_data = current_data

            # 刷新头像显示
            new_pixmap = QPixmap(self.char_path)
            self.avatar_label.setPixmap(new_pixmap)

            # 刷新左侧列表
            self.main_window.load_initial_data()

            QMessageBox.information(self, "成功", "头像已成功更换并保存！")

        except Exception as e:
            QMessageBox.critical(self, "更换失败", f"发生错误：\n{str(e)}")

    def __init__(self, char_path, char_info, data_manager, main_window):
        super().__init__()
        # === Token 计数器初始化 ===
        try:
            self.tokenizer = tiktoken.get_encoding("cl100k_base")  # 通用编码，中文效果还可以
        except:
            self.tokenizer = None
        self.char_path = char_path
        self.char_data = char_info['data']
        self.char_format = char_info['format']
        self.data_manager = data_manager
        self.main_window = main_window
        self.widgets = {}
        self.text_widgets = []
        self.book_entries_data = []
        self.collapsible_boxes = {}
        self.is_modified = False
        self._book_tab_loaded = False  # 新增：标记世界书是否已加载
        self.book_list_widget = None  # 用于存放世界书列表

        self.init_ui()
        self.update_font_size(11)

    def init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(12, 12, 12, 12)
        main_layout.setSpacing(10)

        header = self.create_header()
        main_layout.addWidget(header)

        self.tabs = QTabWidget()
        self.profile_tab = QWidget()
        self.book_tab = QWidget()
        self.tabs.addTab(self.profile_tab, "角色档案")
        self.tabs.addTab(self.book_tab, "世界书")

        main_layout.addWidget(self.tabs)

        bottom = QHBoxLayout()
        self.save_btn = QPushButton("保存所有修改")
        self.save_btn.setObjectName("primaryButton")
        self.save_btn.setFixedHeight(36)
        self.save_btn.clicked.connect(self.save_changes)
        bottom.addStretch()
        bottom.addWidget(self.save_btn)
        main_layout.addLayout(bottom)

        if self.char_data.get('data', {}).get('is_sd_card'):
            self.set_read_only(True)

        # 延迟加载角色档案
        from PySide6.QtCore import QTimer
        QTimer.singleShot(0, self._load_profile_tab)

        # ====================== 关键修复 ======================
        # 直接加载世界书（新列表很轻量，不需要懒加载）
        self.populate_book_tab(self.book_tab)
        # ====================================================

        self.is_modified = False
    def _deferred_populate(self, profile_tab, book_tab):
        """延迟加载重内容，避免打开大卡时卡顿"""
        self.populate_profile_tab(profile_tab)
        self.populate_book_tab(book_tab)

    def _load_profile_tab(self):
        """加载角色档案标签页（带保护，防止快速切换时崩溃）"""
        if not self or not hasattr(self, 'profile_tab'):
            return
        try:
            self.populate_profile_tab(self.profile_tab)
        except RuntimeError:
            # 对象已被销毁，忽略
            pass

    def _on_tab_changed(self, index):
        """标签页切换时触发"""
        # 如果切换到世界书标签页（索引为1），且还没加载过，则加载
        if index == 1 and not self._book_tab_loaded:
            self._load_book_tab()

    def create_header(self):
        header_frame = QFrame()
        header_frame.setStyleSheet("""
            QFrame {
                background-color: #FFFFFF;
                border: 1px solid #E2E8F0;
                border-radius: 10px;
            }
        """)
        layout = QHBoxLayout(header_frame)
        layout.setContentsMargins(14, 10, 14, 10)
        layout.setSpacing(14)

        self.avatar_label = RoundedAvatarLabel()
        pixmap = QPixmap(self.char_path)
        if not pixmap.isNull():
            self.avatar_label.setPixmap(pixmap)
            self.avatar_label.mousePressEvent = self.change_avatar
        layout.addWidget(self.avatar_label, alignment=Qt.AlignTop)

        # === Token 计数显示 ===
        self.token_label = QLabel("Token: --")
        self.token_label.setStyleSheet("""
            QLabel {
                font-size: 13px;
                color: #166534;
                background-color: #DCFCE7;
                border: 1px solid #86EFAC;
                border-radius: 6px;
                padding: 4px 10px;
                font-weight: 600;
            }
        """)
        self.token_label.setToolTip("点击查看详细 Token 分布")
        if hasattr(self, 'show_token_detail'):
            self.token_label.mousePressEvent = self.show_token_detail
        layout.addWidget(self.token_label, alignment=Qt.AlignTop)

        info_layout = QVBoxLayout()
        info_layout.setSpacing(4)

        self.name_edit = QLineEdit()
        self.name_edit.textChanged.connect(self.update_token_count)
        self.name_edit.setText(self.char_data.get('data', {}).get('name', '') or self.char_data.get('name', ''))
        self.name_edit.setStyleSheet("font-size: 18px; font-weight: 700; border: none; background: transparent;")
        info_layout.addWidget(self.name_edit)

        meta = QHBoxLayout()
        self.creator_edit = QLineEdit()
        self.creator_edit.textChanged.connect(self.update_token_count)
        self.creator_edit.textChanged.connect(self._mark_as_modified)
        self.creator_edit.setPlaceholderText("创建者")
        self.creator_edit.setText(self.char_data.get('data', {}).get('creator', ''))
        self.creator_edit.setFixedWidth(140)

        self.version_edit = QLineEdit()
        self.version_edit.textChanged.connect(self.update_token_count)
        self.version_edit.textChanged.connect(self._mark_as_modified)
        self.version_edit.setPlaceholderText("版本")
        self.version_edit.setText(self.char_data.get('data', {}).get('character_version', ''))
        self.version_edit.setFixedWidth(90)

        meta.addWidget(self.creator_edit)
        meta.addWidget(self.version_edit)
        meta.addStretch()
        info_layout.addLayout(meta)

        layout.addLayout(info_layout, 1)

        self.header_save_btn = QPushButton("保存")
        self.header_save_btn.setObjectName("primaryButton")
        self.header_save_btn.setFixedSize(70, 32)
        self.header_save_btn.clicked.connect(self.save_changes)
        layout.addWidget(self.header_save_btn, alignment=Qt.AlignTop)

        return header_frame

    def populate_profile_tab(self, tab):
        tab_layout = QVBoxLayout(tab)
        tab_layout.setContentsMargins(0, 6, 0, 0)
        tab_layout.setSpacing(8)

        control = QHBoxLayout()
        control.addStretch()

        module_btn = QPushButton("模块显示")
        module_btn.setFixedWidth(78)
        module_btn.setFixedHeight(28)
        module_btn.clicked.connect(self.show_module_menu)
        control.addWidget(module_btn)

        font_label = QLabel("字体:")
        self.font_spinbox = QSpinBox()
        self.font_spinbox.setRange(9, 17)
        self.font_spinbox.setValue(11)
        self.font_spinbox.valueChanged.connect(self.update_font_size)
        control.addWidget(font_label)
        control.addWidget(self.font_spinbox)
        tab_layout.addLayout(control)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)

        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setSpacing(8)
        content_layout.setContentsMargins(2, 2, 2, 2)

        data_source = self.char_data.get('data', self.char_data)

        sections = {
            "核心设定": ["description", "personality", "scenario"],
            "对话相关": ["first_mes", "alternate_greetings", "mes_example"],
            "高级指令": ["system_prompt", "post_history_instructions"],
            "元数据": ["creator", "character_version", "tags", "creator_notes"],
            "扩展": ["extensions"]
        }

        field_labels = {
            "description": "描述与设定",
            "personality": "性格",
            "scenario": "场景",
            "first_mes": "开场白",
            "alternate_greetings": "备用问候语（每行一个）",
            "mes_example": "对话示例",
            "system_prompt": "系统提示",
            "post_history_instructions": "后历史指令",
            "creator": "创建者",
            "character_version": "版本",
            "tags": "标签（逗号分隔）",
            "creator_notes": "创建者笔记",
            "extensions": "扩展数据 (JSON)"
        }

        for section_title, keys in sections.items():
            box = CollapsibleBox(section_title)
            box_layout = QVBoxLayout()
            box_layout.setSpacing(6)

            for key in keys:
                value = data_source.get(key, "")
                if key == "tags" and isinstance(value, list):
                    value = ", ".join(value)
                elif key == "alternate_greetings" and isinstance(value, list):
                    value = "\n".join(value)
                elif key == "extensions" and isinstance(value, dict):
                    value = json.dumps(value, indent=2, ensure_ascii=False)

                is_multiline = key not in ["creator", "character_version", "tags"]
                self.create_field_row(box_layout, field_labels.get(key, key), key, value, multiline=is_multiline)

            box.setContentLayout(box_layout)
            content_layout.addWidget(box)
            self.collapsible_boxes[section_title] = box

        content_layout.addStretch()
        scroll.setWidget(content)
        tab_layout.addWidget(scroll)

    def create_field_row(self, parent_layout, label_text, key, value, multiline=False):
        h = QHBoxLayout()
        h.setSpacing(8)

        label = QLabel(label_text)
        label.setFixedWidth(105)
        label.setStyleSheet("color: #475569; font-size: 12px;")
        h.addWidget(label)

        if multiline:
            widget = AutoResizingTextEdit()
            widget.setPlainText(str(value) if value else "")
            widget.adjust_height_to_content()  # ← 新增：初始化时主动调整高度
        else:
            widget = QLineEdit()
            widget.setText(str(value) if value else "")

        self.widgets[key] = widget
        widget.textChanged.connect(self.update_token_count)
        if isinstance(widget, (QLineEdit, QTextEdit)):
            widget.textChanged.connect(self._mark_as_modified)


        h.addWidget(widget)
        parent_layout.addLayout(h)

    def show_module_menu(self):
        menu = QMenu(self)
        for title, box in self.collapsible_boxes.items():
            action = QAction(title, menu)
            action.setCheckable(True)
            action.setChecked(box.content_area.isVisible())
            action.triggered.connect(lambda checked, b=box: b.toggle_button.setChecked(checked))
            menu.addAction(action)

        btn = self.sender()
        if btn:
            menu.exec(btn.mapToGlobal(btn.rect().bottomLeft()))

    def populate_book_tab(self, tab):
        layout = QVBoxLayout(tab)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        book_data = self.char_data.get('data', {}).get('character_book', {'name': '', 'entries': []})

        # 顶部工具栏
        top = QHBoxLayout()
        add_btn = QPushButton("添加新条目")
        add_btn.setObjectName("primaryButton")
        add_btn.clicked.connect(self.add_new_book_entry)

        export_btn = QPushButton("导出世界书")
        export_btn.clicked.connect(self.export_world_book)

        self.book_name_edit = QLineEdit(book_data.get("name", ""))
        self.name_edit.textChanged.connect(self._mark_as_modified)
        self.book_name_edit.setPlaceholderText("世界书名称")

        top.addWidget(QLabel("名称:"))
        top.addWidget(self.book_name_edit)
        top.addStretch()
        top.addWidget(add_btn)
        top.addWidget(export_btn)
        layout.addLayout(top)

        # 世界书列表（轻量级）
        self.book_list_widget = QListWidget()
        self.book_list_widget.setAlternatingRowColors(True)
        self.book_list_widget.itemDoubleClicked.connect(self._edit_book_entry)
        layout.addWidget(self.book_list_widget)

        # 初始化数据
        self.book_entries_data = book_data.get('entries', [])
        self._refresh_book_list()
    def _refresh_book_list(self):
        """刷新世界书列表显示"""
        self.book_list_widget.clear()
        for i, entry in enumerate(self.book_entries_data):
            keys_str = ", ".join(entry.get("keys", []))[:40]
            enabled = "✓" if entry.get("enabled", True) else "✗"
            title = f"#{i+1}  {enabled}  {keys_str}"
            item = QListWidgetItem(title)
            item.setData(Qt.UserRole, i)  # 保存索引
            self.book_list_widget.addItem(item)

    def _edit_book_entry(self, item):
        """双击编辑世界书条目"""
        index = item.data(Qt.UserRole)
        if index is None:
            return

        dialog = EditBookEntryDialog(self.book_entries_data[index], self)
        if dialog.exec():
            new_data = dialog.get_data()
            self.book_entries_data[index]["keys"] = new_data["keys"]
            self.book_entries_data[index]["content"] = new_data["content"]
            self.book_entries_data[index]["enabled"] = new_data["enabled"]
            self._refresh_book_list()  # 刷新列表显示

    def add_new_book_entry(self):
        dialog = AddEntryDialog(self)
        if dialog.exec():
            new_data = dialog.get_data()
            if not new_data["keys"] and not new_data["content"]:
                QMessageBox.warning(self, "提示", "关键词和内容不能都为空")
                return

            full_entry = {
                "keys": new_data["keys"],
                "content": new_data["content"],
                "enabled": new_data["enabled"],
                "comment": "", "constant": False, "selective": True,
                "insertion_order": 100, "extensions": {}, "id": 0
            }
            self.book_entries_data.append(full_entry)
            self._refresh_book_list()

    def update_font_size(self, size):
        font = QFont()
        font.setPointSize(size)
        for w in self.text_widgets:
            w.setFont(font)
            if isinstance(w, AutoResizingTextEdit):
                w.updateGeometry()

    def set_read_only(self, read_only):
        for w in self.widgets.values():
            if isinstance(w, (QLineEdit, QTextEdit)):
                w.setReadOnly(read_only)
        self.save_btn.setEnabled(not read_only)
        if hasattr(self, 'header_save_btn'):
            self.header_save_btn.setEnabled(not read_only)

    def save_changes(self):
        updated = self.char_data.copy()
        if 'data' not in updated:
            updated['data'] = {}
        target = updated['data']

        target['name'] = self.name_edit.text().strip()
        target['creator'] = self.creator_edit.text().strip()
        target['character_version'] = self.version_edit.text().strip()

        for key, widget in self.widgets.items():
            if key in ['name', 'creator', 'character_version']:
                continue
            if key == "tags":
                target[key] = [t.strip() for t in widget.text().split(',') if t.strip()]
            elif key == "alternate_greetings":
                target[key] = [line.strip() for line in widget.toPlainText().split('\n') if line.strip()]
            elif key == "extensions":
                try:
                    target[key] = json.loads(widget.toPlainText()) if widget.toPlainText().strip() else {}
                except:
                    QMessageBox.warning(self, "保存失败", "扩展数据 JSON 格式错误")
                    return
            elif isinstance(widget, QTextEdit):
                target[key] = widget.toPlainText().strip()
            else:
                target[key] = widget.text().strip()

        # ====================== 世界书部分（关键修改） ======================
        target.setdefault('character_book', {})
        target['character_book']['name'] = self.book_name_edit.text().strip()
        target['character_book']['entries'] = self.book_entries_data  # 直接使用新数据
        # ================================================================

        success, msg = write_character_data_to_png(self.char_path, updated)
        if success:
            QMessageBox.information(self, "成功", "保存成功！")
            self.char_data = updated
            self.data_manager.characters[self.char_path]['data'] = updated
            self.main_window.update_status("保存成功")
            self.is_modified = False
            self.main_window.load_initial_data()
        else:
            QMessageBox.critical(self, "失败", msg)

    def export_world_book(self):
        book = self.char_data.get('data', {}).get('character_book')
        if not book or not book.get('entries'):
            QMessageBox.warning(self, "提示", "没有世界书内容")
            return

        name = self.char_data.get('data', {}).get('name', '角色')
        path, _ = QFileDialog.getSaveFileName(self, "导出世界书", f"{name}-世界书.json", "JSON (*.json)")
        if path:
            try:
                with open(path, 'w', encoding='utf-8') as f:
                    json.dump(book, f, indent=2, ensure_ascii=False)
                QMessageBox.information(self, "成功", f"已导出到 {path}")
            except Exception as e:
                QMessageBox.critical(self, "失败", str(e))

    def has_unsaved_changes(self):
        return self.is_modified

    def _mark_as_modified(self):
        self.is_modified = True

    def count_tokens(self, text: str) -> int:
        """计算 Token 数量（支持自定义公式）"""
        if not text:
            return 0

        token_settings = {}
        if hasattr(self.main_window, 'data_manager') and hasattr(self.main_window.data_manager, 'config'):
            token_settings = self.main_window.data_manager.config.get("token_settings", {})

        use_custom = token_settings.get("use_custom_formula", False)

        if use_custom:
            # 使用自定义公式计算
            en_coef = token_settings.get("english_char_coef", 0.3)
            zh_coef = token_settings.get("chinese_char_coef", 0.6)

            # 简单统计中英文字符数量
            en_count = sum(1 for c in text if ord(c) < 128)  # 英文及符号
            zh_count = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')  # 中文

            # 其他字符按 0.5 计算
            other_count = len(text) - en_count - zh_count

            total = en_count * en_coef + zh_count * zh_coef + other_count * 0.5
            return max(1, int(round(total)))

        else:
            # 默认使用 tiktoken 精确计算
            if not hasattr(self, 'tokenizer') or self.tokenizer is None:
                return max(1, len(text) // 3)
            try:
                return len(self.tokenizer.encode(text))
            except:
                return max(1, len(text) // 3)