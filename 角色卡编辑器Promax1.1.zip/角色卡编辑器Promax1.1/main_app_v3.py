#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
角色卡工作台 V3 - 完整可用版
"""
import warnings
warnings.filterwarnings("ignore", message="iCCP: known incorrect sRGB profile")
import sys
import os
import shutil
import json

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QTreeWidget, QTreeWidgetItem, QLineEdit,
    QFileDialog, QMessageBox, QInputDialog, QSplitter, QMenu,
    QLabel, QFrame, QStatusBar, QDialog, QComboBox, QTabWidget
)
from PySide6.QtGui import QIcon, QPixmap, QAction
from PySide6.QtCore import Qt, QSize

from core_utils import (
    extract_character_data_from_png, write_character_data_to_png,
    CARD_WORKSPACE, BOOK_WORKSPACE, CONFIG_FILE
)
from data_manager import DataManager
from detail_view import DetailWidget
from create_card_dialog import CreateCharacterDialog

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("角色卡工作台 V3")
        self.setGeometry(120, 120, 1680, 960)
        self.data_manager = DataManager()
        self.apply_style()
        self.init_ui()
        self.load_initial_data()
        self.update_status("就绪")

    def apply_style(self):
        style_path = os.path.join(os.path.dirname(__file__), "style.qss")
        if os.path.exists(style_path):
            with open(style_path, 'r', encoding='utf-8') as f:
                self.setStyleSheet(f.read())

    def init_ui(self):
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout(main_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        toolbar = self.create_toolbar()
        main_layout.addWidget(toolbar)

        content_widget = QWidget()
        content_layout = QHBoxLayout(content_widget)
        content_layout.setContentsMargins(10, 4, 10, 10)
        content_layout.setSpacing(10)

        left_panel = self.create_left_panel()
        self.right_panel = QWidget()
        self.right_layout = QVBoxLayout(self.right_panel)
        self.show_empty_state()

        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(left_panel)
        splitter.addWidget(self.right_panel)
        splitter.setSizes([380, 1200])

        content_layout.addWidget(splitter)
        main_layout.addWidget(content_widget)

        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)

    def create_toolbar(self):
        toolbar_frame = QFrame()
        toolbar_frame.setStyleSheet("QFrame { background-color: #FFFFFF; border-bottom: 1px solid #E2E8F0; }")
        toolbar_layout = QHBoxLayout(toolbar_frame)
        toolbar_layout.setContentsMargins(10, 3, 10, 3)
        toolbar_layout.setSpacing(6)

        title_label = QLabel("角色卡工作台")
        title_label.setStyleSheet("font-size: 14px; font-weight: 700; color: #0F172A;")
        toolbar_layout.addWidget(title_label)
        toolbar_layout.addStretch()

        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("搜索角色名称...")
        self.search_edit.setFixedWidth(240)
        self.search_edit.setClearButtonEnabled(True)
        self.search_edit.textChanged.connect(self.filter_character_tree)
        toolbar_layout.addWidget(self.search_edit)
        toolbar_layout.addSpacing(10)

        import_folder_btn = QPushButton("导入文件夹")
        import_folder_btn.clicked.connect(self.import_folder)

        export_selected_btn = QPushButton("导出选中")
        export_selected_btn.clicked.connect(self.export_selected)

        delete_selected_btn = QPushButton("删除选中")
        delete_selected_btn.clicked.connect(self.delete_selected)

        # ==================== 移动选中按钮（正确顺序）====================
        move_selected_btn = QPushButton("移动选中")
        move_selected_btn.clicked.connect(self.move_selected_to_group)
        # ================================================================

        self.import_btn = QPushButton("导入角色卡")
        self.import_btn.clicked.connect(self.import_files)

        self.create_btn = QPushButton("新建角色卡")
        self.create_btn.setObjectName("primaryButton")
        self.create_btn.clicked.connect(self.create_new_card)

        self.add_group_btn = QPushButton("添加分组")
        self.add_group_btn.clicked.connect(self.add_group)

        # 新增：设置按钮
        settings_btn = QPushButton("设置")
        settings_btn.clicked.connect(self.show_settings_dialog)

        # 添加到布局
        toolbar_layout.addWidget(import_folder_btn)
        toolbar_layout.addWidget(export_selected_btn)
        toolbar_layout.addWidget(delete_selected_btn)
        toolbar_layout.addWidget(move_selected_btn)  # 放在这里是正确的
        toolbar_layout.addWidget(self.import_btn)
        toolbar_layout.addWidget(self.create_btn)
        toolbar_layout.addWidget(self.add_group_btn)
        toolbar_layout.addWidget(settings_btn)

        return toolbar_frame
    def move_selected_to_group(self):
        selected_items = self.char_tree.selectedItems()
        if not selected_items:
            QMessageBox.information(self, "提示", "请先选择要移动的角色卡")
            return

        # 过滤掉分组，只保留角色
        char_items = [item for item in selected_items if item.data(0, Qt.UserRole) != "group"]
        if not char_items:
            QMessageBox.information(self, "提示", "请选择角色卡而不是分组")
            return

        # 弹出分组选择弹窗（复用逻辑）
        dialog = QDialog(self)
        dialog.setWindowTitle("移动选中角色到分组")
        dialog.setMinimumWidth(320)

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        label = QLabel(f"请选择要移动到的分组（共选中 {len(char_items)} 个角色）")
        layout.addWidget(label)

        combo = QComboBox()
        # 获取所有分组
        all_groups = list(self.data_manager.groups.keys())
        combo.addItems(all_groups)
        layout.addWidget(combo)

        button_layout = QHBoxLayout()
        btn_ok = QPushButton("确定移动")
        btn_cancel = QPushButton("取消")
        btn_ok.setObjectName("primaryButton")

        button_layout.addStretch()
        button_layout.addWidget(btn_cancel)
        button_layout.addWidget(btn_ok)
        layout.addLayout(button_layout)

        btn_ok.clicked.connect(dialog.accept)
        btn_cancel.clicked.connect(dialog.reject)

        if dialog.exec() != QDialog.Accepted:
            return

        target_group = combo.currentText()
        if not target_group:
            return

        # 执行移动
        moved_count = 0
        for item in char_items:
            char_path = item.data(0, Qt.UserRole)
            if not char_path:
                continue

            current_group = item.parent().text(0) if item.parent() else "未分组"

            # 从原分组移除
            if current_group in self.data_manager.groups:
                if char_path in self.data_manager.groups[current_group]:
                    self.data_manager.groups[current_group].remove(char_path)

            # 添加到目标分组
            self.data_manager.groups.setdefault(target_group, []).append(char_path)
            moved_count += 1

        self.data_manager.save_config()
        self.load_initial_data()
        self.update_status(f"已将 {moved_count} 个角色移动到「{target_group}」")

    def show_settings_dialog(self):
        from PySide6.QtWidgets import QDialog, QFormLayout, QDoubleSpinBox, QCheckBox, QDialogButtonBox

        dialog = QDialog(self)
        dialog.setWindowTitle("Token 计算设置")
        dialog.setMinimumWidth(420)

        layout = QFormLayout(dialog)
        layout.setSpacing(10)

        token_settings = self.data_manager.config.get("token_settings", {})

        # 是否启用自定义公式
        self.use_custom_cb = QCheckBox("启用自定义估算公式（适合 DeepSeek 等模型）")
        self.use_custom_cb.setChecked(token_settings.get("use_custom_formula", False))
        layout.addRow(self.use_custom_cb)

        # 英文字符系数
        self.en_coef = QDoubleSpinBox()
        self.en_coef.setRange(0.01, 5.0)
        self.en_coef.setDecimals(2)
        self.en_coef.setSingleStep(0.05)
        self.en_coef.setValue(token_settings.get("english_char_coef", 0.3))
        layout.addRow("1个英文字符 ≈", self.en_coef)

        # 中文字符系数
        self.zh_coef = QDoubleSpinBox()
        self.zh_coef.setRange(0.01, 5.0)
        self.zh_coef.setDecimals(2)
        self.zh_coef.setSingleStep(0.05)
        self.zh_coef.setValue(token_settings.get("chinese_char_coef", 0.6))
        layout.addRow("1个中文字符 ≈", self.zh_coef)

        # 按钮
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.accepted.connect(dialog.accept)
        button_box.rejected.connect(dialog.reject)
        layout.addRow(button_box)

        if dialog.exec() == QDialog.Accepted:
            # 保存设置
            if "token_settings" not in self.data_manager.config:
                self.data_manager.config["token_settings"] = {}

            self.data_manager.config["token_settings"]["use_custom_formula"] = self.use_custom_cb.isChecked()
            self.data_manager.config["token_settings"]["english_char_coef"] = round(self.en_coef.value(), 2)
            self.data_manager.config["token_settings"]["chinese_char_coef"] = round(self.zh_coef.value(), 2)

            self.data_manager.save_config()

            # 刷新当前打开的角色卡 Token 显示
            if hasattr(self, 'detail_widget') and self.detail_widget:
                self.detail_widget.update_token_count()

    def create_left_panel(self):
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(8)

        header_label = QLabel("角色列表")
        header_label.setStyleSheet("font-size: 13px; font-weight: 600; color: #334155; padding-left: 6px;")
        left_layout.addWidget(header_label)

        self.char_tree = QTreeWidget()
        self.char_tree.setHeaderHidden(True)
        self.char_tree.setSelectionMode(QTreeWidget.ExtendedSelection)
        self.char_tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.char_tree.customContextMenuRequested.connect(self.show_tree_context_menu)
        self.char_tree.itemDoubleClicked.connect(self.open_detail_view)
        self.char_tree.setDragEnabled(True)
        self.char_tree.setAcceptDrops(True)
        self.char_tree.setDropIndicatorShown(True)
        self.char_tree.setDragDropMode(QTreeWidget.InternalMove)
        self.char_tree.dropEvent = self.handle_drop_event

        left_layout.addWidget(self.char_tree)
        return left_widget

    def show_empty_state(self):
        for i in reversed(range(self.right_layout.count())):
            widget = self.right_layout.itemAt(i).widget()
            if widget:
                widget.setParent(None)

        empty_widget = QWidget()
        empty_layout = QVBoxLayout(empty_widget)
        empty_layout.setAlignment(Qt.AlignCenter)
        empty_layout.setSpacing(6)

        icon_label = QLabel("📁")
        icon_label.setStyleSheet("font-size: 48px; color: #CBD5E1;")
        icon_label.setAlignment(Qt.AlignCenter)

        title_label = QLabel("还没有打开任何角色卡")
        title_label.setStyleSheet("font-size: 15px; font-weight: 600; color: #64748B;")
        title_label.setAlignment(Qt.AlignCenter)

        desc_label = QLabel("从左侧选择一个角色，或点击上方按钮新建")
        desc_label.setStyleSheet("font-size: 12px; color: #94A3B8;")
        desc_label.setAlignment(Qt.AlignCenter)

        new_btn = QPushButton("新建角色卡")
        new_btn.setObjectName("primaryButton")
        new_btn.setFixedWidth(140)
        new_btn.setFixedHeight(32)
        new_btn.clicked.connect(self.create_new_card)

        empty_layout.addWidget(icon_label)
        empty_layout.addWidget(title_label)
        empty_layout.addWidget(desc_label)
        empty_layout.addSpacing(6)
        empty_layout.addWidget(new_btn, alignment=Qt.AlignCenter)

        self.right_layout.addWidget(empty_widget)

    def filter_character_tree(self, text):
        text = text.lower().strip()
        root = self.char_tree.invisibleRootItem()
        for i in range(root.childCount()):
            group_item = root.child(i)
            group_visible = False
            for j in range(group_item.childCount()):
                char_item = group_item.child(j)
                char_name = char_item.text(0).lower()
                match = text in char_name
                char_item.setHidden(not match)
                if match:
                    group_visible = True
            group_item.setHidden(not group_visible and bool(text))

    def show_tree_context_menu(self, position):
        item = self.char_tree.itemAt(position)
        if not item:
            return

        menu = QMenu(self)
        item_type = item.data(0, Qt.UserRole)

        if item_type == "group":
            # 分组菜单
            rename_action = QAction("重命名分组", self)
            delete_action = QAction("删除分组", self)
            rename_action.triggered.connect(lambda: self.rename_group(item))
            delete_action.triggered.connect(lambda: self.delete_group(item))
            menu.addAction(rename_action)
            menu.addAction(delete_action)

        else:
            # 角色菜单
            export_action = QAction("导出此角色卡", self)
            move_action = QAction("移动到分组", self)
            delete_action = QAction("删除角色卡", self)

            export_action.triggered.connect(lambda: self.export_character(item))
            move_action.triggered.connect(lambda: self.show_move_dialog(item))
            delete_action.triggered.connect(lambda: self.delete_character(item))

            menu.addAction(export_action)
            menu.addAction(move_action)
            menu.addAction(delete_action)

        menu.exec(self.char_tree.mapToGlobal(position))

    def export_selected(self):
        """批量导出选中的角色卡"""
        selected_items = self.char_tree.selectedItems()
        if not selected_items:
            QMessageBox.information(self, "提示", "请先选择要导出的角色卡")
            return

        folder_path = QFileDialog.getExistingDirectory(self, "选择导出文件夹")
        if not folder_path:
            return

        exported_count = 0
        for item in selected_items:
            if item.data(0, Qt.UserRole) == "group":
                continue
            char_path = item.data(0, Qt.UserRole)
            if char_path and os.path.exists(char_path):
                char_name = item.text(0).split(" · ")[0]
                save_path = os.path.join(folder_path, f"{char_name}.png")
                try:
                    shutil.copy2(char_path, save_path)
                    exported_count += 1
                except Exception as e:
                    print(f"导出失败 {char_name}: {e}")

        self.update_status(f"成功导出 {exported_count} 个角色卡")
        QMessageBox.information(self, "导出完成", f"已导出 {exported_count} 个角色卡到：\n{folder_path}")

    def delete_selected(self):
        """批量删除选中的角色卡"""
        selected_items = self.char_tree.selectedItems()
        if not selected_items:
            QMessageBox.information(self, "提示", "请先选择要删除的角色卡")
            return

        reply = QMessageBox.question(
            self, "确认删除",
            f"确定要删除选中的 {len(selected_items)} 个角色卡吗？\n此操作不可恢复！"
        )
        if reply != QMessageBox.Yes:
            return

        deleted_count = 0
        for item in selected_items:
            if item.data(0, Qt.UserRole) == "group":
                continue
            char_path = item.data(0, Qt.UserRole)
            if char_path:
                try:
                    group_name = item.parent().text(0) if item.parent() else "未分组"
                    if char_path in self.data_manager.groups.get(group_name, []):
                        self.data_manager.groups[group_name].remove(char_path)
                    self.data_manager.characters.pop(char_path, None)
                    if os.path.exists(char_path):
                        os.remove(char_path)
                    deleted_count += 1
                except Exception as e:
                    print(f"删除失败: {e}")

        self.data_manager.save_config()
        self.load_initial_data()
        self.show_empty_state()
        self.update_status(f"已删除 {deleted_count} 个角色卡")

    def move_selected_to_group(self):
        selected_items = self.char_tree.selectedItems()
        if not selected_items:
            QMessageBox.information(self, "提示", "请先选择要移动的角色卡")
            return

        # 过滤掉分组，只保留角色
        char_items = [item for item in selected_items if item.data(0, Qt.UserRole) != "group"]
        if not char_items:
            QMessageBox.information(self, "提示", "请选择角色卡而不是分组")
            return

        # 弹出分组选择弹窗（复用逻辑）
        dialog = QDialog(self)
        dialog.setWindowTitle("移动选中角色到分组")
        dialog.setMinimumWidth(320)

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        label = QLabel(f"请选择要移动到的分组（共选中 {len(char_items)} 个角色）")
        layout.addWidget(label)

        combo = QComboBox()
        # 获取所有分组
        all_groups = list(self.data_manager.groups.keys())
        combo.addItems(all_groups)
        layout.addWidget(combo)

        button_layout = QHBoxLayout()
        btn_ok = QPushButton("确定移动")
        btn_cancel = QPushButton("取消")
        btn_ok.setObjectName("primaryButton")

        button_layout.addStretch()
        button_layout.addWidget(btn_cancel)
        button_layout.addWidget(btn_ok)
        layout.addLayout(button_layout)

        btn_ok.clicked.connect(dialog.accept)
        btn_cancel.clicked.connect(dialog.reject)

        if dialog.exec() != QDialog.Accepted:
            return

        target_group = combo.currentText()
        if not target_group:
            return

        # 执行移动
        moved_count = 0
        for item in char_items:
            char_path = item.data(0, Qt.UserRole)
            if not char_path:
                continue

            current_group = item.parent().text(0) if item.parent() else "未分组"

            # 从原分组移除
            if current_group in self.data_manager.groups:
                if char_path in self.data_manager.groups[current_group]:
                    self.data_manager.groups[current_group].remove(char_path)

            # 添加到目标分组
            self.data_manager.groups.setdefault(target_group, []).append(char_path)
            moved_count += 1

        self.data_manager.save_config()
        self.load_initial_data()
        self.update_status(f"已将 {moved_count} 个角色移动到「{target_group}」")

    def import_folder(self):
        folder_path = QFileDialog.getExistingDirectory(self, "选择包含角色卡的文件夹")
        if not folder_path:
            return

        imported_count = 0
        for filename in os.listdir(folder_path):
            if filename.lower().endswith('.png'):
                src_path = os.path.join(folder_path, filename)
                dest_path = os.path.join(CARD_WORKSPACE, filename)

                if os.path.exists(dest_path):
                    base, ext = os.path.splitext(filename)
                    i = 1
                    while os.path.exists(dest_path):
                        dest_path = os.path.join(CARD_WORKSPACE, f"{base}_{i}{ext}")
                        i += 1

                try:
                    shutil.copy2(src_path, dest_path)
                    self.data_manager.groups.setdefault("未分组", []).append(dest_path)
                    imported_count += 1
                except Exception as e:
                    print(f"导入失败 {filename}: {e}")

        self.data_manager.save_config()
        self.load_initial_data()
        self.update_status(f"成功导入 {imported_count} 个角色卡")

    def create_new_card(self):
        dialog = CreateCharacterDialog(self)
        if dialog.exec():
            card_info, image_path = dialog.get_data()

            greetings_text = card_info.get("alternate_greetings", "")
            alt_greetings_list = [line.strip() for line in greetings_text.split('\n') if line.strip()]
            tags_str = card_info.get("tags", "")
            tags_list = [tag.strip() for tag in tags_str.split(',') if tag.strip()]

            full_card_data = {
                "spec": "chara_card_v2",
                "spec_version": "2.0",
                "data": {
                    "name": card_info.get("name", ""),
                    "description": card_info.get("description", ""),
                    "personality": card_info.get("personality", ""),
                    "scenario": card_info.get("scenario", ""),
                    "first_mes": card_info.get("first_mes", ""),
                    "mes_example": card_info.get("mes_example", ""),
                    "creator_notes": card_info.get("creator_notes", ""),
                    "system_prompt": card_info.get("system_prompt", ""),
                    "post_history_instructions": card_info.get("post_history_instructions", ""),
                    "tags": tags_list,
                    "creator": card_info.get("creator", ""),
                    "character_version": card_info.get("character_version", ""),
                    "alternate_greetings": alt_greetings_list,
                    "character_book": {"name": "", "entries": []},
                    "extensions": {}
                }
            }

            # === 图片处理：统一转成标准 PNG（最稳妥，兼容手动转换的PNG）===
            from PIL import Image
            import tempfile
            import os

            base_name = "".join(x for x in card_info.get("name") if x.isalnum()) or "NewCharacter"
            dest_path = os.path.join(CARD_WORKSPACE, f"{base_name}.png")

            try:
                # 无论你选 JPG 还是 PNG（包括手动转换的），都重新生成一个标准 PNG
                with Image.open(image_path) as img:
                    if img.mode in ("RGBA", "LA", "P"):
                        img = img.convert("RGBA")
                    else:
                        img = img.convert("RGB")

                    # 保存为临时标准 PNG
                    temp_png = tempfile.NamedTemporaryFile(suffix=".png", delete=False)
                    img.save(temp_png.name, "PNG", optimize=True)
                    temp_image_path = temp_png.name

            except Exception as e:
                QMessageBox.critical(self, "图片处理失败", f"无法处理图片：\n{e}")
                return

            # 处理文件名冲突
            if os.path.exists(dest_path):
                i = 1
                while os.path.exists(dest_path):
                    dest_path = os.path.join(CARD_WORKSPACE, f"{base_name}_{i}.png")
                    i += 1

            # 复制处理后的标准 PNG
            try:
                shutil.copy2(temp_image_path, dest_path)
            except Exception as e:
                QMessageBox.critical(self, "文件复制失败", f"无法复制载体图片: {e}")
                return

            success, message = write_character_data_to_png(dest_path, full_card_data)
            if success:
                QMessageBox.information(self, "成功", f"角色卡 '{card_info.get('name')}' 已成功创建！")
                self.data_manager.groups.setdefault("未分组", []).append(dest_path)
                self.data_manager.save_config()
                self.load_initial_data()
            else:
                QMessageBox.critical(self, "写入失败", f"无法将角色数据写入PNG: {message}")
                if os.path.exists(dest_path):
                    os.remove(dest_path)

    def import_files(self):
        original_paths, _ = QFileDialog.getOpenFileNames(self, "选择角色卡", "", "PNG Files (*.png)")
        if not original_paths:
            return
        for original_path in original_paths:
            filename = os.path.basename(original_path)
            dest_path = os.path.join(CARD_WORKSPACE, filename)
            if os.path.exists(dest_path):
                base, ext = os.path.splitext(filename)
                i = 1
                while os.path.exists(dest_path):
                    dest_path = os.path.join(CARD_WORKSPACE, f"{base}_{i}{ext}")
                    i += 1
            shutil.copy2(original_path, dest_path)
            self.data_manager.groups.setdefault("未分组", []).append(dest_path)
        self.data_manager.save_config()
        self.load_initial_data()

    def add_group(self):
        text, ok = QInputDialog.getText(self, '添加分组', '请输入新的分组名称:')
        if ok and text and text not in self.data_manager.groups:
            self.data_manager.groups[text] = []
            self.data_manager.save_config()
            self.load_initial_data()

    def load_initial_data(self):
        self.char_tree.clear()
        for group_name, paths in self.data_manager.groups.items():
            group_item = QTreeWidgetItem(self.char_tree, [group_name])
            group_item.setData(0, Qt.UserRole, "group")
            group_item.setExpanded(True)

            for path in paths:
                char_info = self.data_manager.load_character_data(path)
                if char_info:
                    data = char_info['data']
                    format_str = char_info['format']
                    display_name = data.get("data", {}).get("name") or data.get("name", "未知名称")

                    if format_str and format_str not in ["NovelAI V1"]:
                        display_name += f"  ·  {format_str}"

                    char_item = QTreeWidgetItem(group_item, [display_name])
                    char_item.setData(0, Qt.UserRole, path)

                    if format_str != "Invalid":
                        pixmap = QPixmap(path)
                        icon = QIcon(pixmap.scaled(QSize(48, 48), Qt.KeepAspectRatio, Qt.SmoothTransformation))
                        char_item.setIcon(0, icon)

    def open_detail_view(self, item):
        if item is None:
            return

        try:
            item_data = item.data(0, Qt.UserRole)
            display_name = item.text(0)
        except:
            return

        if item_data == "group" or not isinstance(item_data, str):
            return

        char_path = item_data

        # 检查旧卡是否有未保存修改
        if hasattr(self, 'detail_widget') and self.detail_widget is not None:
            if self.detail_widget.has_unsaved_changes():
                reply = QMessageBox.question(
                    self,
                    "未保存的修改",
                    "当前角色卡有未保存的修改，是否保存？",
                    QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel
                )
                if reply == QMessageBox.Yes:
                    self.detail_widget.save_changes()
                elif reply == QMessageBox.Cancel:
                    return

        # === 更强的安全销毁旧 DetailWidget ===
        if hasattr(self, 'detail_widget') and self.detail_widget is not None:
            try:
                old_widget = self.detail_widget
                self.detail_widget = None
                old_widget.blockSignals(True)
                old_widget.setParent(None)
                old_widget.deleteLater()
            except Exception:
                pass

        # 清空右侧
        for i in reversed(range(self.right_layout.count())):
            item = self.right_layout.itemAt(i)
            if item and item.widget():
                item.widget().setParent(None)

        # 创建新角色卡界面
        char_info = self.data_manager.load_character_data(char_path)
        if not char_info or char_info['format'] == 'Invalid':
            QMessageBox.warning(self, "无法打开", "此文件无法读取或不包含有效的角色数据。")
            return

        self.detail_widget = DetailWidget(char_path, char_info, self.data_manager, self)
        self.right_layout.addWidget(self.detail_widget)
        self.update_status(f"正在编辑：{display_name}")

    def delete_character(self, item):
        char_path = item.data(0, Qt.UserRole)
        char_name = item.text(0)
        reply = QMessageBox.question(self, "确认删除", f"确定要删除角色 '{char_name}' 吗？\n这将从工作区永久删除文件。")
        if reply == QMessageBox.Yes:
            group_name = item.parent().text(0)
            if char_path in self.data_manager.groups[group_name]:
                self.data_manager.groups[group_name].remove(char_path)
            self.data_manager.characters.pop(char_path, None)
            self.data_manager.save_config()
            try:
                os.remove(char_path)
            except OSError as e:
                QMessageBox.critical(self, "删除失败", f"无法删除文件: {e}")
            item.parent().removeChild(item)
            self.show_empty_state()
            self.update_status("角色卡已删除")

    def rename_group(self, item):
        old_name = item.text(0)
        if old_name == "未分组":
            QMessageBox.warning(self, "提示", "「未分组」不能重命名")
            return

        new_name, ok = QInputDialog.getText(self, "重命名分组", "请输入新的分组名称:", text=old_name)
        if ok and new_name and new_name != old_name:
            if new_name in self.data_manager.groups:
                QMessageBox.warning(self, "提示", "该分组名称已存在")
                return

            # 重命名分组
            self.data_manager.groups[new_name] = self.data_manager.groups.pop(old_name)
            self.data_manager.save_config()
            self.load_initial_data()

    def show_move_dialog(self, item):
        char_path = item.data(0, Qt.UserRole)
        current_group = item.parent().text(0) if item.parent() else "未分组"

        # 创建弹窗
        dialog = QDialog(self)
        dialog.setWindowTitle("移动到分组")
        dialog.setMinimumWidth(320)

        layout = QVBoxLayout(dialog)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)

        # 提示文字
        label = QLabel(f"请选择要移动到的分组（当前在「{current_group}」）")
        layout.addWidget(label)

        # 下拉选择框
        combo = QComboBox()
        group_list = [g for g in self.data_manager.groups.keys() if g != current_group]
        combo.addItems(group_list)

        if not group_list:
            QMessageBox.information(self, "提示", "没有其他分组可移动")
            return

        layout.addWidget(combo)

        # 按钮
        button_layout = QHBoxLayout()
        btn_ok = QPushButton("确定移动")
        btn_cancel = QPushButton("取消")
        btn_ok.setObjectName("primaryButton")

        button_layout.addStretch()
        button_layout.addWidget(btn_cancel)
        button_layout.addWidget(btn_ok)
        layout.addLayout(button_layout)

        # 连接信号
        btn_ok.clicked.connect(dialog.accept)
        btn_cancel.clicked.connect(dialog.reject)

        # 显示弹窗
        if dialog.exec() == QDialog.Accepted:
            target_group = combo.currentText()
            if target_group:
                self.move_character_to_group(char_path, target_group, item)

    def move_character_to_group(self, char_path, target_group, item):
        if not char_path or not target_group:
            return

        current_group = item.parent().text(0) if item.parent() else "未分组"

        # 从原分组移除
        if current_group in self.data_manager.groups:
            if char_path in self.data_manager.groups[current_group]:
                self.data_manager.groups[current_group].remove(char_path)

        # 添加到目标分组
        self.data_manager.groups.setdefault(target_group, []).append(char_path)
        self.data_manager.save_config()

        # 刷新列表
        self.load_initial_data()
        self.update_status(f"已将角色移动到「{target_group}」")

    def delete_group(self, item):
        group_name = item.text(0)
        if group_name == "未分组":
            QMessageBox.warning(self, "提示", "「未分组」不能删除")
            return

        reply = QMessageBox.question(
            self, "确认删除",
            f"确定要删除分组「{group_name}」吗？\n该分组下的角色会移动到「未分组」。"
        )
        if reply == QMessageBox.Yes:
            # 把该分组下的角色移到「未分组」
            if group_name in self.data_manager.groups:
                chars = self.data_manager.groups.pop(group_name)
                self.data_manager.groups.setdefault("未分组", []).extend(chars)

            self.data_manager.save_config()
            self.load_initial_data()

    def handle_drop_event(self, event):
        item = self.char_tree.itemAt(event.pos())
        if not item:
            return
        dragged_item = self.char_tree.selectedItems()[0]
        if dragged_item.parent() is None:
            return
        target_group_item = item if item.parent() is None else item.parent()
        old_group_name = dragged_item.parent().text(0)
        new_group_name = target_group_item.text(0)
        char_path = dragged_item.data(0, Qt.UserRole)
        if old_group_name != new_group_name:
            self.data_manager.groups[old_group_name].remove(char_path)
            self.data_manager.groups[new_group_name].append(char_path)
            self.data_manager.save_config()
            dragged_item.parent().removeChild(dragged_item)
            target_group_item.addChild(dragged_item)

    def update_status(self, message):
        self.status_bar.showMessage(message, 3000)

    def closeEvent(self, event):
        try:
            if hasattr(self, 'detail_widget') and self.detail_widget is not None:
                if self.detail_widget.has_unsaved_changes():
                    self.detail_widget.save_changes()

            if hasattr(self, 'data_manager'):
                self.data_manager.save_config()

            event.accept()
        except Exception as e:
            print(f"关闭保存出错: {e}")
            event.accept()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    window = MainWindow()
    window.show()
    sys.exit(app.exec())

